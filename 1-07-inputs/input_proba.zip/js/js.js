document.addEventListener('DOMContentLoaded', function(event) {

    document.getElementById('myButton').addEventListener('click', input_irakurri);

})

function input_irakurri() {
    var irakurketa = "";

    irakurketa = document.getElementById('myInput').value;
    alert("DATO=" + irakurketa);
    document.getElementById('myDiv').innerHTML = "<h1>" + irakurketa + "</h1>";

}